const routeFactory = require('../utils/routeFactory');
const controller = require('../controllers/proveedor.controller');

module.exports = routeFactory(controller);
