const routeFactory = require('../utils/routeFactory');
const controller = require('../controllers/roles.controller');

module.exports = routeFactory(controller);
