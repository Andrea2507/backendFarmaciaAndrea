const routeFactory = require('../utils/routeFactory');
const controller = require('../controllers/medicamento.controller');

module.exports = routeFactory(controller);
