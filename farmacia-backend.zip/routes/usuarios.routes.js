const routeFactory = require('../utils/routeFactory');
const controller = require('../controllers/usuarios.controller');

module.exports = routeFactory(controller);
