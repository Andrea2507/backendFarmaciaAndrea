const routeFactory = require('../utils/routeFactory');
const controller = require('../controllers/lote.controller');

module.exports = routeFactory(controller);
