const routeFactory = require('../utils/routeFactory');
const controller = require('../controllers/venta.controller');

module.exports = routeFactory(controller);
