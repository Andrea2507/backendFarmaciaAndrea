const routeFactory = require('../utils/routeFactory');
const controller = require('../controllers/presentacion.controller');

module.exports = routeFactory(controller);
