const routeFactory = require('../utils/routeFactory');
const controller = require('../controllers/metodosPago.controller');

module.exports = routeFactory(controller);
