const routeFactory = require('../utils/routeFactory');
const controller = require('../controllers/detalleVenta.controller');

module.exports = routeFactory(controller);
