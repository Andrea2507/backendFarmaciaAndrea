const routeFactory = require('../utils/routeFactory');
const controller = require('../controllers/detalleCompra.controller');

module.exports = routeFactory(controller);
