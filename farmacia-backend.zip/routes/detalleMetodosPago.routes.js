const routeFactory = require('../utils/routeFactory');
const controller = require('../controllers/detalleMetodosPago.controller');

module.exports = routeFactory(controller);
