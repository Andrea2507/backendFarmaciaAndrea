const routeFactory = require('../utils/routeFactory');
const controller = require('../controllers/compras.controller');

module.exports = routeFactory(controller);
