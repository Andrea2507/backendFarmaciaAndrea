const { Router } = require('express');

const router = Router();

router.use('/casa-medica', require('./casaMedica.routes'));
router.use('/proveedores', require('./proveedor.routes'));
router.use('/compras', require('./compras.routes'));
router.use('/presentaciones', require('./presentacion.routes'));
router.use('/medicamentos', require('./medicamento.routes'));
router.use('/detalle-compras', require('./detalleCompra.routes'));
router.use('/lotes', require('./lote.routes'));
router.use('/clientes', require('./cliente.routes'));
router.use('/roles', require('./roles.routes'));
router.use('/usuarios', require('./usuarios.routes'));
router.use('/ventas', require('./venta.routes'));
router.use('/detalle-ventas', require('./detalleVenta.routes'));
router.use('/metodos-pago', require('./metodosPago.routes'));
router.use('/detalle-metodos-pago', require('./detalleMetodosPago.routes'));

module.exports = router;
