const routeFactory = require('../utils/routeFactory');
const controller = require('../controllers/casaMedica.controller');

module.exports = routeFactory(controller);
