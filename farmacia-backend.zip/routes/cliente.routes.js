const routeFactory = require('../utils/routeFactory');
const controller = require('../controllers/cliente.controller');

module.exports = routeFactory(controller);
