# Backend - Sistema de Farmacia

API REST construida con **Node.js**, **Express** y **Sequelize** sobre **MySQL**, siguiendo arquitectura **MVC**.

## Estructura del proyecto

```
backend/
├── config/
│   └── database.js          # Conexion Sequelize a MySQL
├── database/
│   └── farmacia_db.sql      # Script completo de creacion de la BD (ejecutar en MySQL)
├── models/                  # Modelos Sequelize (uno por tabla) + index.js con asociaciones
├── controllers/             # Controladores (logica de cada recurso)
├── routes/                  # Rutas Express (una por recurso) + index.js agregador
├── middlewares/
│   └── errorHandler.js      # Manejo de errores y rutas no encontradas
├── utils/
│   ├── crudFactory.js       # Generador de controladores CRUD reutilizable
│   └── routeFactory.js      # Generador de routers REST reutilizable
├── app.js                   # Configuracion de Express
├── server.js                # Punto de entrada (conexion BD + levantar servidor)
├── .env.example              # Variables de entorno de ejemplo
└── package.json
```

## Requisitos

- Node.js 22 o superior
- MySQL 8 (o compatible)

## Instalacion

```bash
cd backend
npm install
cp .env.example .env
# Edita .env con tus credenciales de MySQL
```

## Base de datos

Antes de iniciar el servidor, crea la base de datos ejecutando el script SQL incluido:

```bash
mysql -u root -p < database/farmacia_db.sql
```

Esto crea la base de datos `farmacia_db`, las 14 tablas con sus llaves primarias/foraneas
y algunos datos iniciales (roles, metodos de pago, presentaciones, cliente generico, un usuario administrador).

> Si prefieres que Sequelize cree las tablas automaticamente (sin usar el script SQL),
> pon `DB_SYNC=true` en tu archivo `.env`. No se recomienda usar ambos metodos a la vez.

## Ejecutar el servidor

```bash
npm run dev    # con nodemon (desarrollo)
npm start      # produccion
```

El servidor arrancara en `http://localhost:3000` (o el puerto configurado en `.env`).

## Endpoints disponibles

Todos los recursos exponen el mismo patron REST: `GET /`, `GET /:id`, `POST /`, `PUT /:id`, `DELETE /:id`.

| Recurso                  | Endpoint base                     |
|---------------------------|-----------------------------------|
| Casas medicas              | `/api/casa-medica`                |
| Proveedores                | `/api/proveedores`                |
| Compras                    | `/api/compras`                    |
| Presentaciones             | `/api/presentaciones`             |
| Medicamentos                | `/api/medicamentos`               |
| Detalle de compras          | `/api/detalle-compras`            |
| Lotes                       | `/api/lotes`                      |
| Clientes                    | `/api/clientes`                   |
| Roles                       | `/api/roles`                      |
| Usuarios                    | `/api/usuarios`                   |
| Ventas                      | `/api/ventas`                     |
| Detalle de ventas            | `/api/detalle-ventas`             |
| Metodos de pago              | `/api/metodos-pago`               |
| Detalle de metodos de pago    | `/api/detalle-metodos-pago`       |

Todas las respuestas siguen el formato:

```json
{ "success": true, "data": ... }
```
o en caso de error:
```json
{ "success": false, "message": "..." }
```

Tambien se soporta busqueda y paginacion opcional via query string en los listados, ej:
`GET /api/medicamentos?q=paracetamol&page=1&limit=10`

## Relaciones (todas 1:M, segun el diagrama)

- CasaMedica → Proveedor
- Proveedor → Compras, DetalleCompra
- Compras → DetalleCompra
- Presentacion → Medicamento
- Medicamento → DetalleCompra, Lote, DetalleVenta
- Roles → Usuarios
- Cliente → Venta
- Usuarios → Venta
- Venta → DetalleVenta, DetalleMetodosPago
- MetodosPago → DetalleMetodosPago
