const sequelize = require('../config/database');

const CasaMedica = require('./CasaMedica.model');
const Proveedor = require('./Proveedor.model');
const Compras = require('./Compras.model');
const Presentacion = require('./Presentacion.model');
const Medicamento = require('./Medicamento.model');
const DetalleCompra = require('./DetalleCompra.model');
const Lote = require('./Lote.model');
const Cliente = require('./Cliente.model');
const Roles = require('./Roles.model');
const Usuarios = require('./Usuarios.model');
const Venta = require('./Venta.model');
const DetalleVenta = require('./DetalleVenta.model');
const MetodosPago = require('./MetodosPago.model');
const DetalleMetodosPago = require('./DetalleMetodosPago.model');

/* ==========================================================
   ASOCIACIONES 1:M (segun el diagrama relacional - herencias)
   Todas las relaciones son 1:M. Las tablas "Detalle*" resuelven
   las relaciones M:N como dos relaciones 1:M encadenadas.
   ========================================================== */

// CasaMedica (1) -> (M) Proveedor
CasaMedica.hasMany(Proveedor, { foreignKey: 'id_casa_medica', as: 'proveedores' });
Proveedor.belongsTo(CasaMedica, { foreignKey: 'id_casa_medica', as: 'casaMedica' });

// Proveedor (1) -> (M) Compras
Proveedor.hasMany(Compras, { foreignKey: 'id_proveedor', as: 'compras' });
Compras.belongsTo(Proveedor, { foreignKey: 'id_proveedor', as: 'proveedor' });

// Proveedor (1) -> (M) DetalleCompra
Proveedor.hasMany(DetalleCompra, { foreignKey: 'id_proveedor', as: 'detalleCompras' });
DetalleCompra.belongsTo(Proveedor, { foreignKey: 'id_proveedor', as: 'proveedor' });

// Compras (1) -> (M) DetalleCompra
Compras.hasMany(DetalleCompra, { foreignKey: 'id_compra', as: 'detalles' });
DetalleCompra.belongsTo(Compras, { foreignKey: 'id_compra', as: 'compra' });

// Presentacion (1) -> (M) Medicamento
Presentacion.hasMany(Medicamento, { foreignKey: 'id_presentacion', as: 'medicamentos' });
Medicamento.belongsTo(Presentacion, { foreignKey: 'id_presentacion', as: 'presentacion' });

// Medicamento (1) -> (M) DetalleCompra
Medicamento.hasMany(DetalleCompra, { foreignKey: 'id_medicamento', as: 'detalleCompras' });
DetalleCompra.belongsTo(Medicamento, { foreignKey: 'id_medicamento', as: 'medicamento' });

// Medicamento (1) -> (M) Lote
Medicamento.hasMany(Lote, { foreignKey: 'id_medicamento', as: 'lotes' });
Lote.belongsTo(Medicamento, { foreignKey: 'id_medicamento', as: 'medicamento' });

// Medicamento (1) -> (M) DetalleVenta
Medicamento.hasMany(DetalleVenta, { foreignKey: 'id_medicamento', as: 'detalleVentas' });
DetalleVenta.belongsTo(Medicamento, { foreignKey: 'id_medicamento', as: 'medicamento' });

// Roles (1) -> (M) Usuarios
Roles.hasMany(Usuarios, { foreignKey: 'id_rol', as: 'usuarios' });
Usuarios.belongsTo(Roles, { foreignKey: 'id_rol', as: 'rol' });

// Cliente (1) -> (M) Venta
Cliente.hasMany(Venta, { foreignKey: 'id_cliente', as: 'ventas' });
Venta.belongsTo(Cliente, { foreignKey: 'id_cliente', as: 'cliente' });

// Usuarios (1) -> (M) Venta
Usuarios.hasMany(Venta, { foreignKey: 'id_usuario', as: 'ventas' });
Venta.belongsTo(Usuarios, { foreignKey: 'id_usuario', as: 'usuario' });

// Venta (1) -> (M) DetalleVenta
Venta.hasMany(DetalleVenta, { foreignKey: 'id_venta', as: 'detalles' });
DetalleVenta.belongsTo(Venta, { foreignKey: 'id_venta', as: 'venta' });

// Venta (1) -> (M) DetalleMetodosPago
Venta.hasMany(DetalleMetodosPago, { foreignKey: 'id_venta', as: 'detalleMetodosPago' });
DetalleMetodosPago.belongsTo(Venta, { foreignKey: 'id_venta', as: 'venta' });

// MetodosPago (1) -> (M) DetalleMetodosPago
MetodosPago.hasMany(DetalleMetodosPago, { foreignKey: 'id_metodo_pago', as: 'detalles' });
DetalleMetodosPago.belongsTo(MetodosPago, { foreignKey: 'id_metodo_pago', as: 'metodoPago' });

module.exports = {
  sequelize,
  CasaMedica,
  Proveedor,
  Compras,
  Presentacion,
  Medicamento,
  DetalleCompra,
  Lote,
  Cliente,
  Roles,
  Usuarios,
  Venta,
  DetalleVenta,
  MetodosPago,
  DetalleMetodosPago
};
