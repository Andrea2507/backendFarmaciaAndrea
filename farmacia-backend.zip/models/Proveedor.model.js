const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Proveedor = sequelize.define('Proveedor', {
  id_proveedor: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  id_casa_medica: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  nombre_proveedor: {
    type: DataTypes.STRING(150),
    allowNull: false
  },
  telefono_proveedor: {
    type: DataTypes.STRING(20)
  },
  direccion_proveedor: {
    type: DataTypes.STRING(255)
  },
  correo_proveedor: {
    type: DataTypes.STRING(150)
  },
  total_adquirido_proveedor: {
    type: DataTypes.DECIMAL(12, 2),
    defaultValue: 0
  },
  cantidad_adquirido_proveedor: {
    type: DataTypes.INTEGER,
    defaultValue: 0
  },
  estado_proveedor: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: true
  }
}, {
  tableName: 'proveedor',
  timestamps: true
});

module.exports = Proveedor;
