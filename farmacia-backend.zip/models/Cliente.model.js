const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Cliente = sequelize.define('Cliente', {
  id_cliente: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  nombre_cliente: {
    type: DataTypes.STRING(150),
    allowNull: false
  },
  nit_cliente: {
    type: DataTypes.STRING(20),
    defaultValue: 'CF'
  },
  estado_cliente: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: true
  }
}, {
  tableName: 'cliente',
  timestamps: true
});

module.exports = Cliente;
