const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Medicamento = sequelize.define('Medicamento', {
  id_medicamento: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  id_presentacion: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  codigo_barras_medicamento: {
    type: DataTypes.STRING(50),
    unique: true
  },
  nombre_medicamento: {
    type: DataTypes.STRING(150),
    allowNull: false
  },
  cantidad_por_paquete: {
    type: DataTypes.INTEGER,
    defaultValue: 1
  },
  precio_mayorista: {
    type: DataTypes.DECIMAL(10, 2),
    defaultValue: 0
  },
  precio_minimo: {
    type: DataTypes.DECIMAL(10, 2),
    defaultValue: 0
  },
  precio_venta: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false,
    defaultValue: 0
  },
  componente_activo: {
    type: DataTypes.STRING(150)
  },
  venta_libre: {
    type: DataTypes.BOOLEAN,
    defaultValue: true
  },
  existencia_total_medicamento: {
    type: DataTypes.INTEGER,
    defaultValue: 0
  },
  estado_medicamento: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: true
  }
}, {
  tableName: 'medicamento',
  timestamps: true
});

module.exports = Medicamento;
