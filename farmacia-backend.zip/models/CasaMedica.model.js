const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const CasaMedica = sequelize.define('CasaMedica', {
  id_casa_medica: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  nombre_casa_medica: {
    type: DataTypes.STRING(150),
    allowNull: false
  },
  estado_casa_medica: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: true
  }
}, {
  tableName: 'casa_medica',
  timestamps: true
});

module.exports = CasaMedica;
