const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Presentacion = sequelize.define('Presentacion', {
  id_presentacion: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  nombre_presentacion: {
    type: DataTypes.STRING(100),
    allowNull: false
  },
  estado_presentacion: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: true
  }
}, {
  tableName: 'presentacion',
  timestamps: true
});

module.exports = Presentacion;
