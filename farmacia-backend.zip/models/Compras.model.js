const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Compras = sequelize.define('Compras', {
  id_compra: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  id_proveedor: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  fecha_compra: {
    type: DataTypes.DATEONLY,
    allowNull: false
  },
  total_compra: {
    type: DataTypes.DECIMAL(12, 2),
    allowNull: false,
    defaultValue: 0
  },
  estado_compra: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: true
  }
}, {
  tableName: 'compras',
  timestamps: true
});

module.exports = Compras;
