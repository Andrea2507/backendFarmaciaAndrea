const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const DetalleMetodosPago = sequelize.define('DetalleMetodosPago', {
  id_detalle_metodos_pago: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  id_venta: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  id_metodo_pago: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  cantidad_detalle_metodos_pago: {
    type: DataTypes.DECIMAL(12, 2),
    allowNull: false,
    defaultValue: 0
  },
  estado_detalle_metodos_pago: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: true
  }
}, {
  tableName: 'detalle_metodos_pago',
  timestamps: true
});

module.exports = DetalleMetodosPago;
