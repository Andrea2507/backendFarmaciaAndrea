const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Lote = sequelize.define('Lote', {
  id_lote: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  id_medicamento: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  fecha_produccion: {
    type: DataTypes.DATEONLY,
    allowNull: false
  },
  fecha_vencimiento: {
    type: DataTypes.DATEONLY,
    allowNull: false
  },
  precio_lote: {
    type: DataTypes.DECIMAL(10, 2),
    defaultValue: 0
  },
  existencia_lote: {
    type: DataTypes.INTEGER,
    defaultValue: 0
  },
  estado_lote: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: true
  }
}, {
  tableName: 'lote',
  timestamps: true
});

module.exports = Lote;
