const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const DetalleVenta = sequelize.define('DetalleVenta', {
  id_detalle_venta: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  id_venta: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  id_medicamento: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  cantidad_detalle_venta: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 0
  },
  subtotal_detalle_venta: {
    type: DataTypes.DECIMAL(12, 2),
    allowNull: false,
    defaultValue: 0
  },
  estado_detalle_venta: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: true
  }
}, {
  tableName: 'detalle_venta',
  timestamps: true
});

module.exports = DetalleVenta;
