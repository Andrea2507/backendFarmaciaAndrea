const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const DetalleCompra = sequelize.define('DetalleCompra', {
  id_detalle_compra: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  id_compra: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  id_proveedor: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  id_medicamento: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  cantidad_compra: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 0
  },
  subtotal_compra: {
    type: DataTypes.DECIMAL(12, 2),
    allowNull: false,
    defaultValue: 0
  },
  estado_compra: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: true
  }
}, {
  tableName: 'detalle_compra',
  timestamps: true
});

module.exports = DetalleCompra;
