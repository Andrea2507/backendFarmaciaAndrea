const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const MetodosPago = sequelize.define('MetodosPago', {
  id_metodo_pago: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  nombre_metodo_pago: {
    type: DataTypes.STRING(50),
    allowNull: false
  },
  cuenta_metodo_pago: {
    type: DataTypes.STRING(100)
  },
  estado_metodo_pago: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: true
  }
}, {
  tableName: 'metodos_pago',
  timestamps: true
});

module.exports = MetodosPago;
