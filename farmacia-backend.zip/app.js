const express = require('express');
const cors = require('cors');
const morgan = require('morgan');

const routes = require('./routes');
const { notFound, errorHandler } = require('./middlewares/errorHandler');

const app = express();

// Middlewares globales
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(morgan('dev'));

// Ruta de salud
app.get('/', (req, res) => {
  res.json({ success: true, message: 'API Sistema de Farmacia funcionando correctamente' });
});

// Rutas de la API
app.use('/api', routes);

// Manejo de rutas no encontradas y errores
app.use(notFound);
app.use(errorHandler);

module.exports = app;
