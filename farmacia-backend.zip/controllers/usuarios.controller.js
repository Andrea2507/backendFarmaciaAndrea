const bcrypt = require('bcryptjs');
const { Usuarios, Roles } = require('../models');
const crudFactory = require('../utils/crudFactory');

const base = crudFactory(Usuarios, {
  include: [{ model: Roles, as: 'rol' }],
  searchableFields: ['nombre_usuario', 'usuario', 'correo_usuario']
});

// Sobreescribimos create y update para encriptar la contrasena
async function create(req, res) {
  try {
    const body = { ...req.body };
    if (body.password) {
      body.password = await bcrypt.hash(body.password, 10);
    }
    const item = await Usuarios.create(body);
    return res.status(201).json({ success: true, message: 'Usuario creado correctamente', data: item });
  } catch (error) {
    return res.status(400).json({ success: false, message: 'Error al crear el usuario', error: error.message });
  }
}

async function update(req, res) {
  try {
    const item = await Usuarios.findByPk(req.params.id);
    if (!item) {
      return res.status(404).json({ success: false, message: 'Usuario no encontrado' });
    }
    const body = { ...req.body };
    if (body.password) {
      body.password = await bcrypt.hash(body.password, 10);
    } else {
      delete body.password;
    }
    await item.update(body);
    return res.json({ success: true, message: 'Usuario actualizado correctamente', data: item });
  } catch (error) {
    return res.status(400).json({ success: false, message: 'Error al actualizar el usuario', error: error.message });
  }
}

module.exports = { ...base, create, update };
