const { CasaMedica } = require('../models');
const crudFactory = require('../utils/crudFactory');

module.exports = crudFactory(CasaMedica, {
  searchableFields: ['nombre_casa_medica']
});
