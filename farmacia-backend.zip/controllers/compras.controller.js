const { Compras, Proveedor, DetalleCompra, Medicamento } = require('../models');
const crudFactory = require('../utils/crudFactory');

module.exports = crudFactory(Compras, {
  include: [
    { model: Proveedor, as: 'proveedor' },
    { model: DetalleCompra, as: 'detalles', include: [{ model: Medicamento, as: 'medicamento' }] }
  ]
});
