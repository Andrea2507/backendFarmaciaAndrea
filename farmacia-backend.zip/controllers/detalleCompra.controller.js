const { DetalleCompra, Compras, Proveedor, Medicamento } = require('../models');
const crudFactory = require('../utils/crudFactory');

module.exports = crudFactory(DetalleCompra, {
  include: [
    { model: Compras, as: 'compra' },
    { model: Proveedor, as: 'proveedor' },
    { model: Medicamento, as: 'medicamento' }
  ]
});
