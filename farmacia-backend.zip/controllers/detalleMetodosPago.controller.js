const { DetalleMetodosPago, Venta, MetodosPago } = require('../models');
const crudFactory = require('../utils/crudFactory');

module.exports = crudFactory(DetalleMetodosPago, {
  include: [
    { model: Venta, as: 'venta' },
    { model: MetodosPago, as: 'metodoPago' }
  ]
});
