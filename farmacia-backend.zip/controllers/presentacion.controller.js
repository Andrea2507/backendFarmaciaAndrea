const { Presentacion } = require('../models');
const crudFactory = require('../utils/crudFactory');

module.exports = crudFactory(Presentacion, {
  searchableFields: ['nombre_presentacion']
});
