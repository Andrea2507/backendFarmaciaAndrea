const { Lote, Medicamento } = require('../models');
const crudFactory = require('../utils/crudFactory');

module.exports = crudFactory(Lote, {
  include: [{ model: Medicamento, as: 'medicamento' }]
});
