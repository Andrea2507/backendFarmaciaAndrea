const { Cliente } = require('../models');
const crudFactory = require('../utils/crudFactory');

module.exports = crudFactory(Cliente, {
  searchableFields: ['nombre_cliente', 'nit_cliente']
});
