const { Proveedor, CasaMedica } = require('../models');
const crudFactory = require('../utils/crudFactory');

module.exports = crudFactory(Proveedor, {
  include: [{ model: CasaMedica, as: 'casaMedica' }],
  searchableFields: ['nombre_proveedor', 'correo_proveedor']
});
