const { Roles } = require('../models');
const crudFactory = require('../utils/crudFactory');

module.exports = crudFactory(Roles, {
  searchableFields: ['nombre_rol']
});
