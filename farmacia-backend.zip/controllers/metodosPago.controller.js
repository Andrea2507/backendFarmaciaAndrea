const { MetodosPago } = require('../models');
const crudFactory = require('../utils/crudFactory');

module.exports = crudFactory(MetodosPago, {
  searchableFields: ['nombre_metodo_pago']
});
