const { Medicamento, Presentacion } = require('../models');
const crudFactory = require('../utils/crudFactory');

module.exports = crudFactory(Medicamento, {
  include: [{ model: Presentacion, as: 'presentacion' }],
  searchableFields: ['nombre_medicamento', 'codigo_barras_medicamento', 'componente_activo']
});
