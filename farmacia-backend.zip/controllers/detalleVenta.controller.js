const { DetalleVenta, Venta, Medicamento } = require('../models');
const crudFactory = require('../utils/crudFactory');

module.exports = crudFactory(DetalleVenta, {
  include: [
    { model: Venta, as: 'venta' },
    { model: Medicamento, as: 'medicamento' }
  ]
});
