const { Venta, Cliente, Usuarios, DetalleVenta, Medicamento, DetalleMetodosPago, MetodosPago } = require('../models');
const crudFactory = require('../utils/crudFactory');

module.exports = crudFactory(Venta, {
  include: [
    { model: Cliente, as: 'cliente' },
    { model: Usuarios, as: 'usuario' },
    { model: DetalleVenta, as: 'detalles', include: [{ model: Medicamento, as: 'medicamento' }] },
    { model: DetalleMetodosPago, as: 'detalleMetodosPago', include: [{ model: MetodosPago, as: 'metodoPago' }] }
  ]
});
