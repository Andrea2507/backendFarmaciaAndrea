/* eslint-disable no-unused-vars */

// Middleware para rutas no encontradas
function notFound(req, res, next) {
  res.status(404).json({
    success: false,
    message: `Ruta no encontrada: ${req.method} ${req.originalUrl}`
  });
}

// Middleware global de manejo de errores
function errorHandler(err, req, res, next) {
  console.error(err.stack);
  res.status(err.status || 500).json({
    success: false,
    message: err.message || 'Error interno del servidor'
  });
}

module.exports = { notFound, errorHandler };
