const { Router } = require('express');

/**
 * Genera un router REST estandar (GET /, GET /:id, POST /, PUT /:id, DELETE /:id)
 * a partir de un controlador creado con crudFactory.
 */
function routeFactory(controller) {
  const router = Router();

  router.get('/', controller.getAll);
  router.get('/:id', controller.getById);
  router.post('/', controller.create);
  router.put('/:id', controller.update);
  router.delete('/:id', controller.remove);

  return router;
}

module.exports = routeFactory;
