/**
 * Factory de controladores CRUD genericos.
 * Recibe un modelo de Sequelize (y opcionalmente su configuracion de "includes"
 * para traer relaciones) y devuelve las 5 operaciones REST estandar.
 *
 * Cada controlador especifico (en /controllers) usa esta fabrica y puede
 * sobreescribir o extender el comportamiento si necesita logica de negocio
 * adicional (ej. actualizar existencias, calcular totales, etc).
 */
function crudFactory(model, options = {}) {
  const { include = [], searchableFields = [] } = options;

  return {
    async getAll(req, res) {
      try {
        const { page, limit, q } = req.query;
        const where = {};

        if (q && searchableFields.length) {
          const { Op } = require('sequelize');
          where[Op.or] = searchableFields.map((field) => ({
            [field]: { [Op.like]: `%${q}%` }
          }));
        }

        const queryOptions = { where, include, order: [[model.primaryKeyAttribute, 'DESC']] };

        if (page && limit) {
          queryOptions.limit = parseInt(limit, 10);
          queryOptions.offset = (parseInt(page, 10) - 1) * parseInt(limit, 10);
          const { count, rows } = await model.findAndCountAll(queryOptions);
          return res.json({
            success: true,
            data: rows,
            pagination: {
              total: count,
              page: parseInt(page, 10),
              limit: parseInt(limit, 10),
              totalPages: Math.ceil(count / parseInt(limit, 10))
            }
          });
        }

        const data = await model.findAll(queryOptions);
        return res.json({ success: true, data });
      } catch (error) {
        return res.status(500).json({ success: false, message: 'Error al obtener los registros', error: error.message });
      }
    },

    async getById(req, res) {
      try {
        const item = await model.findByPk(req.params.id, { include });
        if (!item) {
          return res.status(404).json({ success: false, message: 'Registro no encontrado' });
        }
        return res.json({ success: true, data: item });
      } catch (error) {
        return res.status(500).json({ success: false, message: 'Error al obtener el registro', error: error.message });
      }
    },

    async create(req, res) {
      try {
        const item = await model.create(req.body);
        return res.status(201).json({ success: true, message: 'Registro creado correctamente', data: item });
      } catch (error) {
        return res.status(400).json({ success: false, message: 'Error al crear el registro', error: error.message });
      }
    },

    async update(req, res) {
      try {
        const item = await model.findByPk(req.params.id);
        if (!item) {
          return res.status(404).json({ success: false, message: 'Registro no encontrado' });
        }
        await item.update(req.body);
        return res.json({ success: true, message: 'Registro actualizado correctamente', data: item });
      } catch (error) {
        return res.status(400).json({ success: false, message: 'Error al actualizar el registro', error: error.message });
      }
    },

    async remove(req, res) {
      try {
        const item = await model.findByPk(req.params.id);
        if (!item) {
          return res.status(404).json({ success: false, message: 'Registro no encontrado' });
        }
        await item.destroy();
        return res.json({ success: true, message: 'Registro eliminado correctamente' });
      } catch (error) {
        return res.status(500).json({ success: false, message: 'Error al eliminar el registro', error: error.message });
      }
    }
  };
}

module.exports = crudFactory;
