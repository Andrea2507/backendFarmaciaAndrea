const { Sequelize } = require('sequelize');
require('dotenv').config();

const sequelize = new Sequelize(
  process.env.DB_NAME || 'farmacia_db',
  process.env.DB_USER || 'root',
  process.env.DB_PASSWORD || '',
  {
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 3306,
    dialect: 'mysql',
    logging: false,
    define: {
      // Usamos snake_case tal cual el diagrama, sin timestamps automaticos de nombre distinto
      underscored: false,
      freezeTableName: true,
      timestamps: true
    },
    timezone: '-06:00' // Ajustar segun zona horaria (Guatemala)
  }
);

module.exports = sequelize;
