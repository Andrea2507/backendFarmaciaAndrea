# Frontend - Sistema de Farmacia

Interfaz construida con **Vue 3** + **Vite**, con un diseño oscuro inspirado en las capturas
de referencia (sidebar lateral, tarjetas de resumen y tablas de datos con acciones).

## Estructura

```
frontend/
├── src/
│   ├── assets/main.css          # Tema oscuro y estilos globales (variables CSS)
│   ├── components/
│   │   ├── Icon.vue             # Iconos SVG livianos (sin dependencias externas)
│   │   ├── StatCard.vue         # Tarjeta de estadistica para el dashboard
│   │   ├── Modal.vue            # Modal reutilizable
│   │   └── GenericCrudView.vue  # Tabla + formulario CRUD reutilizable
│   ├── layouts/
│   │   └── AdminLayout.vue      # Sidebar + topbar
│   ├── views/                   # Una vista por entidad (Medicamentos, Ventas, etc.)
│   ├── services/                # Cliente Axios + servicios REST por recurso
│   ├── router/index.js          # Rutas de la aplicacion
│   └── main.js
├── index.html
├── vite.config.js
└── package.json
```

## Requisitos

- Node.js 22 o superior
- El backend corriendo (ver carpeta `backend/`)

## Instalacion

```bash
cd frontend
npm install
cp .env.example .env
# Edita VITE_API_URL si tu backend corre en otra URL/puerto
```

## Ejecutar en desarrollo

```bash
npm run dev
```

Abre `http://localhost:5173`.

## Compilar para produccion

```bash
npm run build
```

Los archivos listos para desplegar quedan en `dist/`.

## Como esta organizada la logica CRUD

Cada vista (Medicamentos, Proveedores, Clientes, etc.) es un archivo pequeño que configura
`GenericCrudView` con:

- `columns`: que columnas mostrar en la tabla (soporta rutas anidadas como `presentacion.nombre_presentacion`,
  formato de moneda, fecha y "badges" de estado).
- `fields`: que campos mostrar en el formulario de creacion/edicion (texto, numero, fecha, booleano
  o un `select` que carga sus opciones desde otro recurso relacionado, por ejemplo el listado de
  presentaciones al crear un medicamento).

Esto evita repetir la logica de listar/crear/editar/eliminar en cada pantalla.
