<template>
  <div class="layout" :class="{ collapsed }">
    <aside class="sidebar">
      <div class="brand">
        <span class="brand-icon"><Icon name="pill" :size="20" /></span>
        <span class="brand-name" v-if="!collapsed">Farmacia</span>
        <button class="collapse-btn" @click="collapsed = !collapsed">
          <Icon name="chevronLeft" :size="16" />
        </button>
      </div>

      <nav class="nav">
        <p class="nav-label" v-if="!collapsed">General</p>
        <router-link to="/" class="nav-item" exact-active-class="active">
          <Icon name="dashboard" /> <span v-if="!collapsed">Dashboard</span>
        </router-link>

        <p class="nav-label" v-if="!collapsed">Inventario</p>
        <router-link to="/medicamentos" class="nav-item" active-class="active">
          <Icon name="pill" /> <span v-if="!collapsed">Medicamentos</span>
        </router-link>
        <router-link to="/presentaciones" class="nav-item" active-class="active">
          <Icon name="layers" /> <span v-if="!collapsed">Presentaciones</span>
        </router-link>
        <router-link to="/lotes" class="nav-item" active-class="active">
          <Icon name="package" /> <span v-if="!collapsed">Lotes</span>
        </router-link>

        <p class="nav-label" v-if="!collapsed">Compras</p>
        <router-link to="/proveedores" class="nav-item" active-class="active">
          <Icon name="truck" /> <span v-if="!collapsed">Proveedores</span>
        </router-link>
        <router-link to="/casas-medicas" class="nav-item" active-class="active">
          <Icon name="building" /> <span v-if="!collapsed">Casas Medicas</span>
        </router-link>
        <router-link to="/compras" class="nav-item" active-class="active">
          <Icon name="cart" /> <span v-if="!collapsed">Compras</span>
        </router-link>

        <p class="nav-label" v-if="!collapsed">Ventas</p>
        <router-link to="/ventas" class="nav-item" active-class="active">
          <Icon name="receipt" /> <span v-if="!collapsed">Ventas</span>
        </router-link>
        <router-link to="/clientes" class="nav-item" active-class="active">
          <Icon name="users" /> <span v-if="!collapsed">Clientes</span>
        </router-link>
        <router-link to="/metodos-pago" class="nav-item" active-class="active">
          <Icon name="card" /> <span v-if="!collapsed">Metodos de Pago</span>
        </router-link>

        <p class="nav-label" v-if="!collapsed">Administracion</p>
        <router-link to="/usuarios" class="nav-item" active-class="active">
          <Icon name="user" /> <span v-if="!collapsed">Usuarios</span>
        </router-link>
        <router-link to="/roles" class="nav-item" active-class="active">
          <Icon name="shield" /> <span v-if="!collapsed">Roles</span>
        </router-link>
      </nav>
    </aside>

    <div class="main">
      <header class="topbar">
        <h1 class="page-title">{{ pageTitle }}</h1>
        <div class="topbar-actions">
          <button class="icon-btn"><Icon name="moon" /></button>
          <button class="icon-btn bell-btn">
            <Icon name="bell" />
            <span class="dot"></span>
          </button>
          <button class="icon-btn"><Icon name="gear" /></button>
          <button class="icon-btn"><Icon name="clock" /></button>
          <div class="avatar">FA</div>
          <div class="search-box">
            <Icon name="search" :size="16" />
            <input type="text" placeholder="Buscar..." />
          </div>
        </div>
      </header>

      <main class="content">
        <router-view />
      </main>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue';
import { useRoute } from 'vue-router';
import Icon from '../components/Icon.vue';

const collapsed = ref(false);
const route = useRoute();

const titles = {
  dashboard: 'Bienvenido',
  medicamentos: 'Medicamentos',
  presentaciones: 'Presentaciones',
  lotes: 'Lotes',
  proveedores: 'Proveedores',
  'casas-medicas': 'Casas Medicas',
  compras: 'Compras',
  ventas: 'Ventas',
  clientes: 'Clientes',
  'metodos-pago': 'Metodos de Pago',
  usuarios: 'Usuarios',
  roles: 'Roles'
};

const pageTitle = computed(() => titles[route.name] || '');
</script>

<style scoped>
.layout {
  display: flex;
  min-height: 100vh;
}

.sidebar {
  width: 250px;
  background: var(--bg-sidebar);
  border-right: 1px solid var(--border-color);
  flex-shrink: 0;
  transition: width 0.2s ease;
  overflow-y: auto;
}
.layout.collapsed .sidebar {
  width: 76px;
}

.brand {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 22px 20px;
  border-bottom: 1px solid var(--border-color);
  position: relative;
}
.brand-icon {
  width: 34px;
  height: 34px;
  border-radius: 9px;
  background: var(--accent-soft);
  color: var(--accent);
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}
.brand-name {
  font-weight: 700;
  font-size: 17px;
  letter-spacing: 0.02em;
}
.collapse-btn {
  margin-left: auto;
  background: none;
  border: none;
  color: var(--text-secondary);
  display: flex;
  align-items: center;
}

.nav {
  padding: 14px 12px;
}
.nav-label {
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: var(--text-muted);
  margin: 16px 10px 8px;
  font-weight: 600;
}
.nav-label:first-child {
  margin-top: 0;
}
.nav-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 10px 12px;
  border-radius: 8px;
  color: var(--text-secondary);
  font-size: 13.5px;
  font-weight: 500;
  margin-bottom: 2px;
  white-space: nowrap;
}
.nav-item:hover {
  background: var(--bg-card-alt);
  color: var(--text-primary);
}
.nav-item.active {
  background: var(--accent-soft);
  color: var(--accent);
}

.main {
  flex: 1;
  display: flex;
  flex-direction: column;
  min-width: 0;
}

.topbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 20px 28px;
  border-bottom: 1px solid var(--border-color);
}
.page-title {
  font-size: 20px;
  font-weight: 700;
  margin: 0;
  letter-spacing: 0.02em;
}
.topbar-actions {
  display: flex;
  align-items: center;
  gap: 10px;
}
.bell-btn {
  position: relative;
}
.dot {
  position: absolute;
  top: 6px;
  right: 7px;
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: var(--danger);
  border: 1.5px solid var(--bg-body);
}
.avatar {
  width: 34px;
  height: 34px;
  border-radius: 50%;
  background: var(--accent);
  color: #fff;
  font-size: 12px;
  font-weight: 700;
  display: flex;
  align-items: center;
  justify-content: center;
}
.search-box {
  display: flex;
  align-items: center;
  gap: 8px;
  background: var(--bg-card);
  border: 1px solid var(--border-color);
  border-radius: 8px;
  padding: 8px 14px;
  color: var(--text-secondary);
}
.search-box input {
  background: transparent;
  border: none;
  outline: none;
  color: var(--text-primary);
  font-size: 13.5px;
  width: 160px;
}

.content {
  padding: 26px 28px;
  flex: 1;
  overflow-y: auto;
}
</style>
