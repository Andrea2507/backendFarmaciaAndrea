<template>
  <div>
    <div class="toolbar">
      <div class="search-box card">
        <Icon name="search" :size="16" />
        <input type="text" v-model="search" placeholder="Buscar..." />
      </div>
      <button class="btn btn-primary" @click="openCreate">
        <Icon name="plus" :size="16" /> {{ addLabel }}
      </button>
    </div>

    <div class="card table-wrap">
      <table>
        <thead>
          <tr>
            <th v-for="col in columns" :key="col.key">{{ col.label }}</th>
            <th style="width:120px">Accion</th>
          </tr>
        </thead>
        <tbody>
          <tr v-if="loading">
            <td :colspan="columns.length + 1" class="empty-state">Cargando...</td>
          </tr>
          <tr v-else-if="filteredRows.length === 0">
            <td :colspan="columns.length + 1" class="empty-state">No hay registros para mostrar.</td>
          </tr>
          <tr v-for="row in filteredRows" :key="row[idKey]">
            <td v-for="col in columns" :key="col.key">
              <span v-if="col.badge">
                <span :class="['badge', resolve(row, col.key) ? 'badge-success' : 'badge-danger']">
                  {{ resolve(row, col.key) ? (col.trueLabel || 'Activo') : (col.falseLabel || 'Inactivo') }}
                </span>
              </span>
              <span v-else>{{ formatValue(resolve(row, col.key), col) }}</span>
            </td>
            <td>
              <div class="actions">
                <button class="icon-btn edit" @click="openEdit(row)"><Icon name="edit" :size="16" /></button>
                <button class="icon-btn delete" @click="confirmDelete(row)"><Icon name="trash" :size="16" /></button>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <Modal v-model="showModal" :title="editingItem ? `Editar ${title}` : `Nuevo ${title}`">
      <form @submit.prevent="save">
        <div class="form-group" v-for="field in fields" :key="field.key">
          <label>{{ field.label }}</label>

          <select
            v-if="field.type === 'select'"
            class="form-control"
            v-model="form[field.key]"
            :required="field.required"
          >
            <option value="" disabled>Selecciona una opcion</option>
            <option v-for="opt in relationOptions[field.key] || []" :key="opt.value" :value="opt.value">
              {{ opt.label }}
            </option>
          </select>

          <select
            v-else-if="field.type === 'boolean'"
            class="form-control"
            v-model="form[field.key]"
          >
            <option :value="true">Activo</option>
            <option :value="false">Inactivo</option>
          </select>

          <input
            v-else
            class="form-control"
            :type="field.type || 'text'"
            v-model="form[field.key]"
            :required="field.required"
            :step="field.type === 'number' ? '0.01' : undefined"
          />
        </div>

        <div class="form-actions">
          <button type="button" class="btn btn-outline" @click="showModal = false">Cancelar</button>
          <button type="submit" class="btn btn-primary" :disabled="saving">
            {{ saving ? 'Guardando...' : 'Guardar' }}
          </button>
        </div>
      </form>
    </Modal>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue';
import Icon from './Icon.vue';
import Modal from './Modal.vue';

const props = defineProps({
  service: { type: Object, required: true },
  title: { type: String, required: true },
  addLabel: { type: String, default: 'Agregar' },
  idKey: { type: String, default: null },
  columns: { type: Array, required: true }, // [{ key, label, badge, trueLabel, falseLabel }]
  fields: { type: Array, required: true } // [{ key, label, type, required, relation:{service,valueKey,labelKey} }]
});

const rows = ref([]);
const loading = ref(true);
const saving = ref(false);
const search = ref('');
const showModal = ref(false);
const editingItem = ref(null);
const form = ref({});
const relationOptions = ref({});

const idKey = computed(() => props.idKey || guessIdKey());

function guessIdKey() {
  // Busca el primer campo que empiece con "id_" en la primera fila, si no, usa "id"
  if (rows.value.length) {
    const key = Object.keys(rows.value[0]).find((k) => k.startsWith('id_'));
    if (key) return key;
  }
  return 'id';
}

function resolve(obj, path) {
  return path.split('.').reduce((acc, key) => (acc ? acc[key] : undefined), obj);
}

function formatValue(value, col) {
  if (value === null || value === undefined || value === '') return '—';
  if (col.money) return `Q ${Number(value).toFixed(2)}`;
  if (col.date) return new Date(value).toLocaleDateString('es-GT');
  return value;
}

const filteredRows = computed(() => {
  if (!search.value) return rows.value;
  const q = search.value.toLowerCase();
  return rows.value.filter((row) =>
    props.columns.some((col) => String(resolve(row, col.key) ?? '').toLowerCase().includes(q))
  );
});

async function loadRows() {
  loading.value = true;
  try {
    const res = await props.service.getAll();
    rows.value = res.data || [];
  } catch (err) {
    console.error('Error al cargar los datos', err);
  } finally {
    loading.value = false;
  }
}

async function loadRelationOptions() {
  for (const field of props.fields) {
    if (field.type === 'select' && field.relation) {
      try {
        const res = await field.relation.service.getAll();
        relationOptions.value[field.key] = (res.data || []).map((item) => ({
          value: item[field.relation.valueKey],
          label: item[field.relation.labelKey]
        }));
      } catch (err) {
        console.error('Error al cargar opciones de relacion', err);
      }
    }
  }
}

function defaultFormValues() {
  const obj = {};
  props.fields.forEach((f) => {
    obj[f.key] = f.type === 'boolean' ? true : '';
  });
  return obj;
}

function openCreate() {
  editingItem.value = null;
  form.value = defaultFormValues();
  showModal.value = true;
}

function openEdit(row) {
  editingItem.value = row;
  const obj = {};
  props.fields.forEach((f) => {
    obj[f.key] = row[f.key];
  });
  form.value = obj;
  showModal.value = true;
}

async function save() {
  saving.value = true;
  try {
    if (editingItem.value) {
      await props.service.update(editingItem.value[idKey.value], form.value);
    } else {
      await props.service.create(form.value);
    }
    showModal.value = false;
    await loadRows();
  } catch (err) {
    alert(err.response?.data?.message || 'Ocurrio un error al guardar el registro');
  } finally {
    saving.value = false;
  }
}

async function confirmDelete(row) {
  if (!window.confirm('¿Deseas eliminar este registro? Esta accion no se puede deshacer.')) return;
  try {
    await props.service.remove(row[idKey.value]);
    await loadRows();
  } catch (err) {
    alert(err.response?.data?.message || 'Ocurrio un error al eliminar el registro');
  }
}

onMounted(() => {
  loadRows();
  loadRelationOptions();
});
</script>

<style scoped>
.toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 20px;
  gap: 14px;
}
.search-box {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 9px 14px;
  color: var(--text-secondary);
  flex: 1;
  max-width: 320px;
}
.search-box input {
  background: transparent;
  border: none;
  outline: none;
  color: var(--text-primary);
  font-size: 13.5px;
  width: 100%;
}
.table-wrap {
  overflow-x: auto;
  padding: 4px 20px;
}
.empty-state {
  text-align: center;
  color: var(--text-muted);
  padding: 30px 0 !important;
}
.actions {
  display: flex;
  gap: 8px;
}
.form-actions {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  margin-top: 6px;
}
</style>
