<template>
  <div class="stat-card card">
    <div class="stat-icon"><Icon :name="icon" :size="22" /></div>
    <div class="stat-body">
      <span class="stat-label">{{ label }}</span>
      <span class="stat-value">{{ value }}</span>
    </div>
    <div class="stat-footer" v-if="trend !== null || footerText">
      <span v-if="trend !== null" :class="['trend', trend >= 0 ? 'up' : 'down']">
        {{ trend >= 0 ? '▲' : '▼' }} {{ Math.abs(trend) }}%
      </span>
      <span class="trend-period">{{ period || footerText }}</span>
    </div>
  </div>
</template>

<script setup>
import Icon from './Icon.vue';

defineProps({
  icon: { type: String, default: 'circle' },
  label: { type: String, required: true },
  value: { type: [String, Number], required: true },
  trend: { type: Number, default: null },
  period: { type: String, default: '' },
  footerText: { type: String, default: '' }
});
</script>

<style scoped>
.stat-card {
  padding: 22px;
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 16px;
  position: relative;
}
.stat-icon {
  width: 52px;
  height: 52px;
  border-radius: 12px;
  background: var(--accent-soft);
  color: var(--accent);
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}
.stat-body {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  margin-left: auto;
  text-align: right;
}
.stat-label {
  color: var(--text-secondary);
  font-size: 13px;
}
.stat-value {
  font-size: 24px;
  font-weight: 700;
  margin-top: 4px;
}
.stat-footer {
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  border-top: 1px solid var(--border-color);
  padding-top: 14px;
  font-size: 13px;
}
.trend.up { color: var(--success); font-weight: 600; }
.trend.down { color: var(--danger); font-weight: 600; }
.trend-period { color: var(--text-muted); }
</style>
