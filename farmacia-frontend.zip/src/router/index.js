import { createRouter, createWebHistory } from 'vue-router';
import AdminLayout from '../layouts/AdminLayout.vue';

const routes = [
  {
    path: '/',
    component: AdminLayout,
    children: [
      { path: '', name: 'dashboard', component: () => import('../views/Dashboard.vue') },
      { path: 'medicamentos', name: 'medicamentos', component: () => import('../views/Medicamentos.vue') },
      { path: 'presentaciones', name: 'presentaciones', component: () => import('../views/Presentaciones.vue') },
      { path: 'lotes', name: 'lotes', component: () => import('../views/Lotes.vue') },
      { path: 'proveedores', name: 'proveedores', component: () => import('../views/Proveedores.vue') },
      { path: 'casas-medicas', name: 'casas-medicas', component: () => import('../views/CasasMedicas.vue') },
      { path: 'compras', name: 'compras', component: () => import('../views/Compras.vue') },
      { path: 'ventas', name: 'ventas', component: () => import('../views/Ventas.vue') },
      { path: 'clientes', name: 'clientes', component: () => import('../views/Clientes.vue') },
      { path: 'metodos-pago', name: 'metodos-pago', component: () => import('../views/MetodosPago.vue') },
      { path: 'usuarios', name: 'usuarios', component: () => import('../views/Usuarios.vue') },
      { path: 'roles', name: 'roles', component: () => import('../views/Roles.vue') }
    ]
  }
];

const router = createRouter({
  history: createWebHistory(),
  routes
});

export default router;
