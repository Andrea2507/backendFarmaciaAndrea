import { createCrudService } from './crudService';

export const casaMedicaService = createCrudService('casa-medica');
export const proveedorService = createCrudService('proveedores');
export const comprasService = createCrudService('compras');
export const presentacionService = createCrudService('presentaciones');
export const medicamentoService = createCrudService('medicamentos');
export const detalleCompraService = createCrudService('detalle-compras');
export const loteService = createCrudService('lotes');
export const clienteService = createCrudService('clientes');
export const rolesService = createCrudService('roles');
export const usuariosService = createCrudService('usuarios');
export const ventaService = createCrudService('ventas');
export const detalleVentaService = createCrudService('detalle-ventas');
export const metodosPagoService = createCrudService('metodos-pago');
export const detalleMetodosPagoService = createCrudService('detalle-metodos-pago');
