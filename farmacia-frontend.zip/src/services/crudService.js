import http from './http';

/**
 * Genera un objeto con los 5 metodos REST estandar para un recurso dado.
 * Todos los servicios especificos (medicamentoService, clienteService, etc.)
 * se construyen a partir de esta fabrica para evitar repetir codigo.
 */
export function createCrudService(resourcePath) {
  return {
    getAll(params = {}) {
      return http.get(`/${resourcePath}`, { params }).then((res) => res.data);
    },
    getById(id) {
      return http.get(`/${resourcePath}/${id}`).then((res) => res.data);
    },
    create(payload) {
      return http.post(`/${resourcePath}`, payload).then((res) => res.data);
    },
    update(id, payload) {
      return http.put(`/${resourcePath}/${id}`, payload).then((res) => res.data);
    },
    remove(id) {
      return http.delete(`/${resourcePath}/${id}`).then((res) => res.data);
    }
  };
}
