<template>
  <GenericCrudView
    title="Rol"
    add-label="Agregar Rol"
    :service="rolesService"
    :columns="columns"
    :fields="fields"
  />
</template>

<script setup>
import GenericCrudView from '../components/GenericCrudView.vue';
import { rolesService } from '../services';

const columns = [
  { key: 'nombre_rol', label: 'Nombre' },
  { key: 'estado_rol', label: 'Estado', badge: true }
];

const fields = [
  { key: 'nombre_rol', label: 'Nombre del rol', type: 'text', required: true },
  { key: 'estado_rol', label: 'Estado', type: 'boolean' }
];
</script>
