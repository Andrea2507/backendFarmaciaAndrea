<template>
  <GenericCrudView
    title="Usuario"
    add-label="Agregar Usuario"
    :service="usuariosService"
    :columns="columns"
    :fields="fields"
  />
</template>

<script setup>
import GenericCrudView from '../components/GenericCrudView.vue';
import { usuariosService, rolesService } from '../services';

const columns = [
  { key: 'nombre_usuario', label: 'Nombre' },
  { key: 'usuario', label: 'Usuario' },
  { key: 'rol.nombre_rol', label: 'Rol' },
  { key: 'correo_usuario', label: 'Correo' },
  { key: 'estado_usuario', label: 'Estado', badge: true }
];

const fields = [
  { key: 'nombre_usuario', label: 'Nombre completo', type: 'text', required: true },
  { key: 'usuario', label: 'Nombre de usuario', type: 'text', required: true },
  { key: 'password', label: 'Contrasena (dejar en blanco para no cambiar)', type: 'password' },
  {
    key: 'id_rol',
    label: 'Rol',
    type: 'select',
    required: true,
    relation: { service: rolesService, valueKey: 'id_rol', labelKey: 'nombre_rol' }
  },
  { key: 'telefono_usuario', label: 'Telefono', type: 'text' },
  { key: 'correo_usuario', label: 'Correo electronico', type: 'text' },
  { key: 'dpi_usuario', label: 'DPI', type: 'text' },
  { key: 'estado_usuario', label: 'Estado', type: 'boolean' }
];
</script>
