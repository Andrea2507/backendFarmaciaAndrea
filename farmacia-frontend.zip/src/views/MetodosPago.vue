<template>
  <GenericCrudView
    title="Metodo de Pago"
    add-label="Agregar Metodo de Pago"
    :service="metodosPagoService"
    :columns="columns"
    :fields="fields"
  />
</template>

<script setup>
import GenericCrudView from '../components/GenericCrudView.vue';
import { metodosPagoService } from '../services';

const columns = [
  { key: 'nombre_metodo_pago', label: 'Nombre' },
  { key: 'cuenta_metodo_pago', label: 'Cuenta' },
  { key: 'estado_metodo_pago', label: 'Estado', badge: true }
];

const fields = [
  { key: 'nombre_metodo_pago', label: 'Nombre del metodo de pago', type: 'text', required: true },
  { key: 'cuenta_metodo_pago', label: 'Cuenta asociada', type: 'text' },
  { key: 'estado_metodo_pago', label: 'Estado', type: 'boolean' }
];
</script>
