<template>
  <GenericCrudView
    title="Compra"
    add-label="Agregar Compra"
    :service="comprasService"
    :columns="columns"
    :fields="fields"
  />
</template>

<script setup>
import GenericCrudView from '../components/GenericCrudView.vue';
import { comprasService, proveedorService } from '../services';

const columns = [
  { key: 'proveedor.nombre_proveedor', label: 'Proveedor' },
  { key: 'fecha_compra', label: 'Fecha', date: true },
  { key: 'total_compra', label: 'Total', money: true },
  { key: 'estado_compra', label: 'Estado', badge: true }
];

const fields = [
  {
    key: 'id_proveedor',
    label: 'Proveedor',
    type: 'select',
    required: true,
    relation: { service: proveedorService, valueKey: 'id_proveedor', labelKey: 'nombre_proveedor' }
  },
  { key: 'fecha_compra', label: 'Fecha de compra', type: 'date', required: true },
  { key: 'total_compra', label: 'Total de la compra', type: 'number', required: true },
  { key: 'estado_compra', label: 'Estado', type: 'boolean' }
];
</script>
