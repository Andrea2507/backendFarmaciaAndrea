<template>
  <div>
    <div class="summary-grid">
      <div class="card summary-card">
        <div>
          <span class="summary-label">Total Ventas</span>
          <span class="summary-value">{{ summary.total }}</span>
        </div>
        <div class="summary-icon"><Icon name="receipt" :size="22" /></div>
      </div>
      <div class="card summary-card">
        <div>
          <span class="summary-label">Ventas Activas</span>
          <span class="summary-value">{{ summary.activas }}</span>
        </div>
        <div class="summary-icon"><Icon name="cart" :size="22" /></div>
      </div>
      <div class="card summary-card">
        <div>
          <span class="summary-label">Ventas Anuladas</span>
          <span class="summary-value">{{ summary.anuladas }}</span>
        </div>
        <div class="summary-icon"><Icon name="x" :size="22" /></div>
      </div>
      <div class="card summary-card">
        <div>
          <span class="summary-label">Ingresos Totales</span>
          <span class="summary-value">Q {{ summary.ingresos.toFixed(2) }}</span>
        </div>
        <div class="summary-icon"><Icon name="users" :size="22" /></div>
      </div>
    </div>

    <GenericCrudView
      title="Venta"
      add-label="Agregar Venta"
      :service="ventaService"
      :columns="columns"
      :fields="fields"
    />
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Icon from '../components/Icon.vue';
import GenericCrudView from '../components/GenericCrudView.vue';
import { ventaService, clienteService, usuariosService } from '../services';

const summary = ref({ total: 0, activas: 0, anuladas: 0, ingresos: 0 });

const columns = [
  { key: 'cliente.nombre_cliente', label: 'Cliente' },
  { key: 'usuario.nombre_usuario', label: 'Vendedor' },
  { key: 'fecha_venta', label: 'Fecha', date: true },
  { key: 'total_venta', label: 'Total', money: true },
  { key: 'estado_venta', label: 'Estado', badge: true, trueLabel: 'Completada', falseLabel: 'Anulada' }
];

const fields = [
  {
    key: 'id_cliente',
    label: 'Cliente',
    type: 'select',
    required: true,
    relation: { service: clienteService, valueKey: 'id_cliente', labelKey: 'nombre_cliente' }
  },
  {
    key: 'id_usuario',
    label: 'Vendedor',
    type: 'select',
    required: true,
    relation: { service: usuariosService, valueKey: 'id_usuario', labelKey: 'nombre_usuario' }
  },
  { key: 'fecha_venta', label: 'Fecha de venta', type: 'date', required: true },
  { key: 'total_venta', label: 'Total de la venta', type: 'number', required: true },
  { key: 'estado_venta', label: 'Estado', type: 'boolean' }
];

async function loadSummary() {
  const res = await ventaService.getAll();
  const ventas = res.data || [];
  summary.value.total = ventas.length;
  summary.value.activas = ventas.filter((v) => v.estado_venta).length;
  summary.value.anuladas = ventas.filter((v) => !v.estado_venta).length;
  summary.value.ingresos = ventas.reduce((sum, v) => sum + Number(v.total_venta || 0), 0);
}

loadSummary();
</script>

<style scoped>
.summary-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 18px;
  margin-bottom: 22px;
}
.summary-card {
  padding: 20px;
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.summary-label {
  display: block;
  color: var(--text-secondary);
  font-size: 13px;
  margin-bottom: 8px;
}
.summary-value {
  display: block;
  font-size: 22px;
  font-weight: 700;
}
.summary-icon {
  width: 46px;
  height: 46px;
  border-radius: 12px;
  background: var(--accent-soft);
  color: var(--accent);
  display: flex;
  align-items: center;
  justify-content: center;
}
</style>
