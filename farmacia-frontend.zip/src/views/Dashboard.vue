<template>
  <div>
    <div class="banner card">
      <Icon name="pill" :size="18" />
      <span>Bienvenido al sistema comercial de la farmacia. Aqui puedes ver un resumen general de tu operacion.</span>
    </div>

    <div class="stats-grid">
      <StatCard
        icon="receipt"
        label="Ventas Totales"
        :value="stats.ventas"
        footer-text="Registradas en el sistema"
      />
      <StatCard
        icon="users"
        label="Clientes"
        :value="stats.clientes"
        footer-text="Clientes registrados"
      />
      <StatCard
        icon="pill"
        label="Medicamentos"
        :value="stats.medicamentos"
        footer-text="Productos en catalogo"
      />
      <StatCard
        icon="cart"
        label="Ingresos Totales"
        :value="formatMoney(stats.ingresos)"
        footer-text="Suma de todas las ventas"
      />
    </div>

    <div class="lower-grid">
      <div class="card panel">
        <div class="panel-header">
          <h3>Medicamentos con baja existencia</h3>
        </div>
        <table>
          <thead>
            <tr>
              <th>Medicamento</th>
              <th>Existencia</th>
              <th>Precio de venta</th>
            </tr>
          </thead>
          <tbody>
            <tr v-if="lowStock.length === 0">
              <td colspan="3" class="empty-state">No hay datos disponibles.</td>
            </tr>
            <tr v-for="item in lowStock" :key="item.id_medicamento">
              <td>{{ item.nombre_medicamento }}</td>
              <td>
                <span class="badge badge-danger">{{ item.existencia_total_medicamento }} unidades</span>
              </td>
              <td>Q {{ Number(item.precio_venta).toFixed(2) }}</td>
            </tr>
          </tbody>
        </table>
      </div>

      <div class="card panel">
        <div class="panel-header">
          <h3>Ultimas ventas</h3>
        </div>
        <table>
          <thead>
            <tr>
              <th>Cliente</th>
              <th>Fecha</th>
              <th>Total</th>
            </tr>
          </thead>
          <tbody>
            <tr v-if="recentSales.length === 0">
              <td colspan="3" class="empty-state">No hay datos disponibles.</td>
            </tr>
            <tr v-for="venta in recentSales" :key="venta.id_venta">
              <td>{{ venta.cliente?.nombre_cliente || '—' }}</td>
              <td>{{ new Date(venta.fecha_venta).toLocaleDateString('es-GT') }}</td>
              <td>Q {{ Number(venta.total_venta).toFixed(2) }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import Icon from '../components/Icon.vue';
import StatCard from '../components/StatCard.vue';
import { ventaService, clienteService, medicamentoService } from '../services';

const stats = ref({ ventas: 0, clientes: 0, medicamentos: 0, ingresos: 0 });
const lowStock = ref([]);
const recentSales = ref([]);

function formatMoney(value) {
  return `Q ${Number(value || 0).toFixed(2)}`;
}

async function loadDashboard() {
  try {
    const [ventasRes, clientesRes, medicamentosRes] = await Promise.all([
      ventaService.getAll(),
      clienteService.getAll(),
      medicamentoService.getAll()
    ]);

    const ventas = ventasRes.data || [];
    const clientes = clientesRes.data || [];
    const medicamentos = medicamentosRes.data || [];

    stats.value.ventas = ventas.length;
    stats.value.clientes = clientes.length;
    stats.value.medicamentos = medicamentos.length;
    stats.value.ingresos = ventas.reduce((sum, v) => sum + Number(v.total_venta || 0), 0);

    lowStock.value = medicamentos
      .filter((m) => Number(m.existencia_total_medicamento) < 20)
      .sort((a, b) => a.existencia_total_medicamento - b.existencia_total_medicamento)
      .slice(0, 5);

    recentSales.value = ventas
      .slice()
      .sort((a, b) => new Date(b.fecha_venta) - new Date(a.fecha_venta))
      .slice(0, 5);
  } catch (err) {
    console.error('Error al cargar el dashboard', err);
  }
}

onMounted(loadDashboard);
</script>

<style scoped>
.banner {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 16px 20px;
  color: var(--accent);
  background: var(--accent-soft);
  border-color: transparent;
  margin-bottom: 22px;
  font-size: 13.5px;
}
.stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(230px, 1fr));
  gap: 20px;
  margin-bottom: 22px;
}
.lower-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(340px, 1fr));
  gap: 20px;
}
.panel {
  padding: 20px 22px;
}
.panel-header {
  margin-bottom: 6px;
}
.panel-header h3 {
  margin: 0 0 6px;
  font-size: 15px;
}
.empty-state {
  text-align: center;
  color: var(--text-muted);
  padding: 20px 0 !important;
}
</style>
