<template>
  <GenericCrudView
    title="Casa Medica"
    add-label="Agregar Casa Medica"
    :service="casaMedicaService"
    :columns="columns"
    :fields="fields"
  />
</template>

<script setup>
import GenericCrudView from '../components/GenericCrudView.vue';
import { casaMedicaService } from '../services';

const columns = [
  { key: 'nombre_casa_medica', label: 'Nombre' },
  { key: 'estado_casa_medica', label: 'Estado', badge: true }
];

const fields = [
  { key: 'nombre_casa_medica', label: 'Nombre de la casa medica', type: 'text', required: true },
  { key: 'estado_casa_medica', label: 'Estado', type: 'boolean' }
];
</script>
