<template>
  <GenericCrudView
    title="Cliente"
    add-label="Agregar Cliente"
    :service="clienteService"
    :columns="columns"
    :fields="fields"
  />
</template>

<script setup>
import GenericCrudView from '../components/GenericCrudView.vue';
import { clienteService } from '../services';

const columns = [
  { key: 'nombre_cliente', label: 'Nombre' },
  { key: 'nit_cliente', label: 'NIT' },
  { key: 'estado_cliente', label: 'Estado', badge: true }
];

const fields = [
  { key: 'nombre_cliente', label: 'Nombre del cliente', type: 'text', required: true },
  { key: 'nit_cliente', label: 'NIT', type: 'text' },
  { key: 'estado_cliente', label: 'Estado', type: 'boolean' }
];
</script>
