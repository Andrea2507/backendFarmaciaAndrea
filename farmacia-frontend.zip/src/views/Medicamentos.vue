<template>
  <GenericCrudView
    title="Medicamento"
    add-label="Agregar Medicamento"
    :service="medicamentoService"
    :columns="columns"
    :fields="fields"
  />
</template>

<script setup>
import GenericCrudView from '../components/GenericCrudView.vue';
import { medicamentoService, presentacionService } from '../services';

const columns = [
  { key: 'nombre_medicamento', label: 'Nombre' },
  { key: 'codigo_barras_medicamento', label: 'Codigo de Barras' },
  { key: 'presentacion.nombre_presentacion', label: 'Presentacion' },
  { key: 'precio_venta', label: 'Precio de Venta', money: true },
  { key: 'existencia_total_medicamento', label: 'Existencia' },
  { key: 'estado_medicamento', label: 'Estado', badge: true }
];

const fields = [
  { key: 'nombre_medicamento', label: 'Nombre del medicamento', type: 'text', required: true },
  { key: 'codigo_barras_medicamento', label: 'Codigo de barras', type: 'text' },
  {
    key: 'id_presentacion',
    label: 'Presentacion',
    type: 'select',
    required: true,
    relation: { service: presentacionService, valueKey: 'id_presentacion', labelKey: 'nombre_presentacion' }
  },
  { key: 'componente_activo', label: 'Componente activo', type: 'text' },
  { key: 'cantidad_por_paquete', label: 'Cantidad por paquete', type: 'number' },
  { key: 'precio_mayorista', label: 'Precio mayorista', type: 'number' },
  { key: 'precio_minimo', label: 'Precio minimo', type: 'number' },
  { key: 'precio_venta', label: 'Precio de venta', type: 'number', required: true },
  { key: 'existencia_total_medicamento', label: 'Existencia total', type: 'number' },
  { key: 'venta_libre', label: 'Venta libre', type: 'boolean' },
  { key: 'estado_medicamento', label: 'Estado', type: 'boolean' }
];
</script>
