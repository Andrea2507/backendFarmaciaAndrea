<template>
  <GenericCrudView
    title="Lote"
    add-label="Agregar Lote"
    :service="loteService"
    :columns="columns"
    :fields="fields"
  />
</template>

<script setup>
import GenericCrudView from '../components/GenericCrudView.vue';
import { loteService, medicamentoService } from '../services';

const columns = [
  { key: 'medicamento.nombre_medicamento', label: 'Medicamento' },
  { key: 'fecha_produccion', label: 'Fecha Produccion', date: true },
  { key: 'fecha_vencimiento', label: 'Fecha Vencimiento', date: true },
  { key: 'precio_lote', label: 'Precio', money: true },
  { key: 'existencia_lote', label: 'Existencia' },
  { key: 'estado_lote', label: 'Estado', badge: true }
];

const fields = [
  {
    key: 'id_medicamento',
    label: 'Medicamento',
    type: 'select',
    required: true,
    relation: { service: medicamentoService, valueKey: 'id_medicamento', labelKey: 'nombre_medicamento' }
  },
  { key: 'fecha_produccion', label: 'Fecha de produccion', type: 'date', required: true },
  { key: 'fecha_vencimiento', label: 'Fecha de vencimiento', type: 'date', required: true },
  { key: 'precio_lote', label: 'Precio del lote', type: 'number' },
  { key: 'existencia_lote', label: 'Existencia del lote', type: 'number' },
  { key: 'estado_lote', label: 'Estado', type: 'boolean' }
];
</script>
