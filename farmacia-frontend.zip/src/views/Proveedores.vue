<template>
  <GenericCrudView
    title="Proveedor"
    add-label="Agregar Proveedor"
    :service="proveedorService"
    :columns="columns"
    :fields="fields"
  />
</template>

<script setup>
import GenericCrudView from '../components/GenericCrudView.vue';
import { proveedorService, casaMedicaService } from '../services';

const columns = [
  { key: 'nombre_proveedor', label: 'Nombre' },
  { key: 'casaMedica.nombre_casa_medica', label: 'Casa Medica' },
  { key: 'telefono_proveedor', label: 'Telefono' },
  { key: 'correo_proveedor', label: 'Correo' },
  { key: 'total_adquirido_proveedor', label: 'Total Adquirido', money: true },
  { key: 'estado_proveedor', label: 'Estado', badge: true }
];

const fields = [
  { key: 'nombre_proveedor', label: 'Nombre del proveedor', type: 'text', required: true },
  {
    key: 'id_casa_medica',
    label: 'Casa Medica',
    type: 'select',
    required: true,
    relation: { service: casaMedicaService, valueKey: 'id_casa_medica', labelKey: 'nombre_casa_medica' }
  },
  { key: 'telefono_proveedor', label: 'Telefono', type: 'text' },
  { key: 'direccion_proveedor', label: 'Direccion', type: 'text' },
  { key: 'correo_proveedor', label: 'Correo electronico', type: 'text' },
  { key: 'total_adquirido_proveedor', label: 'Total adquirido', type: 'number' },
  { key: 'cantidad_adquirido_proveedor', label: 'Cantidad adquirida', type: 'number' },
  { key: 'estado_proveedor', label: 'Estado', type: 'boolean' }
];
</script>
