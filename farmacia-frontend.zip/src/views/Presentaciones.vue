<template>
  <GenericCrudView
    title="Presentacion"
    add-label="Agregar Presentacion"
    :service="presentacionService"
    :columns="columns"
    :fields="fields"
  />
</template>

<script setup>
import GenericCrudView from '../components/GenericCrudView.vue';
import { presentacionService } from '../services';

const columns = [
  { key: 'nombre_presentacion', label: 'Nombre' },
  { key: 'estado_presentacion', label: 'Estado', badge: true }
];

const fields = [
  { key: 'nombre_presentacion', label: 'Nombre de la presentacion', type: 'text', required: true },
  { key: 'estado_presentacion', label: 'Estado', type: 'boolean' }
];
</script>
